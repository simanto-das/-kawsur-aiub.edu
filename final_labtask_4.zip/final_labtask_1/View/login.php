<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <form action = "/tasks/Controller/loginaction.php" method = "POST">
      <div>
         <label for="username"><b>Username</b></label>
         <input type="text" name="username"/>
      </div>
      <br /><br />
      <div>
         <label for="psw"><b>Password</b></label>
         <input type="password" name="psw"/>
      </div>
      <br /><br />
      <div>
         <button type="submit" value=" Submit">Submit</button>
      </div>
   </form>

</body>
</html>